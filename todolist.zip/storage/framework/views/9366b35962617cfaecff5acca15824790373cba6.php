<!DOCTYPE html>
<html>
<head>
    <title>Todo List</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp7\htdocs\todolist\resources\views/mails/SendEmailCode.blade.php ENDPATH**/ ?>