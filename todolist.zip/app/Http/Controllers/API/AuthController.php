<?php
namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\controller;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\User;
class AuthController extends Controller
{
    /**
     * Create user
     *
     * @param  [string] name
     * @param  [string] email
     * @param  [string] password
     * @param  [string] password_confirmation
     * @return [string] message
     */
    public function register(Request $request) { 
        $validator = \Validator::make($request->all(), [
            'name' => 'required|max:55', 
           'email' => 'email|required|unique:users',
           'password' => 'required'
       ]);

       if ($validator->fails()) {

          return response()->json(['error'=>$validator->errors()],401);
       }
        $input = $request->all();
        $imagePath = $request->file('profile');
        $imageName = $imagePath->getClientOriginalName();
        $input['profile'] = $request->file('profile')->storeAs('profilePictures', $imageName, 'public');
        //$input['profile']=$request->file('profile')->store('public/uploads');
        $input['password'] = Hash::make($request->password);
      
        $user = User::create($input);
        $details = [
            'title' => 'Mail from Todo List',
            'body' => '1234'
        ];
       
        \Mail::to('phpbasic2019@gmail.com')->send(new \App\Mail\SendEmailCode($details));
        $accessToken = $user->createToken('authToken')->accessToken;

        
        return response([ 'user' => $user, 'access_token' => $accessToken,'emailVerifyCode'=>1234]);
         }
  
    /**
     * Login user and create token
     *
     * @param  [string] email
     * @param  [string] password
     * @param  [boolean] remember_me
     * @return [string] access_token
     * @return [string] token_type
     * @return [string] expires_at
     */
    public function getAllUsers()
    {
        $users =  User::get();
        return response()->json(['success'=>$users]);
    }
    public function login(Request $request)
    {
       
        $validator = \Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required|string',
            'remember_me' => 'boolean'
       ]);

       if ($validator->fails()) {

          return response()->json(['error'=>$validator->errors()],401);
       }

        
        $credentials = request(['email', 'password']);
        if(!Auth::attempt($credentials))
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
            
        $user = $request->user();
        // if ($user->is_admin == 1) {
        //     return view('Backend.Dashboard.Dashboard');
        // } else {
        //     return redirect()->back()->with('error', 'Oppes! You have no permission ');
        // }
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(1);
        $token->save();
        return response()->json([
            'user'    => $user,
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);
    }
    public function resetpassword(Request $request,$id)
    {
        $password = $request->password;
       $user =  User::where('user_id', $id)->update(['password' => Hash::make($password)]);
       return $user;
    }
    public function forgetpassword(Request $request)
    {
        $user = User::where("email",$request->email)->first();
        if ($user) {
            $code =1234;
            $details = [
                'title' => 'Mail from Todo List',
                'body' => "Copy This Four Digit Code ".'1234'
            ];
            \Mail::to('phpbasic2019@gmail.com')->send(new \App\Mail\SendEmailCode($details));
            return response()->json([
                "message" => "Code Send on your Email",
                "verifyCode" => $code
            ]);
        }else{
            return response()->json([
                "message" => "Invalid Email"
            ]);
        }
    }
  
    /**
     * Logout user (Revoke the token)
     *
     * @return [string] message
     */
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }
  
    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function user(Request $request)
    {
        return response()->json($request->user());
    }
}