<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Project;
class ProjectController extends Controller
{
    public function addProject(Request $request)
    {
        $project = new Project;
        $project->name = $request->name;
        $project->user_id = 1;
        $project->favourite = $request->favourite;
        $project->status = 1;

        $project->save();

        return response([ 'success' => "success fully"]);
    }

    public function getAllProjects()
    {
        return Project::get();
    }
    public function getSingleProject(Request $request, $id)
    {
            return Project::find($id);
    }
}
