<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HabitSuggestion extends Model
{
    //
}
