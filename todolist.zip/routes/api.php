<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::get('/registrationForm','Backend\Registeration\RegisterationController@Registeration');
// Route::post('/register','Auth\RegisterController@create');
// Route::get('/userList','Backend\Dashboard\UserController@userList');
// Route::get('/user/{id}','Backend\Dashboard\UserController@user');
// Auth::routes();
// Route::get('/home', 'HomeController@index')->name('home');

Route::post('/register','API\AuthController@register');
Route::post('/login','API\AuthController@login');
Route::post('/forgetpassword','API\AuthController@forgetpassword');


Route::group(['middleware'=>"auth:api"],function(){
    Route::post('/reset-password/{id}', 'Api\AuthController@resetpassword');
Route::post('getAllUsers','API\AuthController@getAllUsers');
Route::post('/addProject','API\ProjectController@addProject');
Route::post('/getAllProjects','API\ProjectController@getAllProjects');
Route::get('/getSingleProject/{id}','API\ProjectController@getSingleProject');

});